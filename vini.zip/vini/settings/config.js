const config = {
        botName: 'ViniModder',
        ownerName: 'VINIMODDER',
        youtube: 'www.youtube.com/channel/vinimodder',
        instagram: 'INSTAGRAM_LINK',
}
