### Oii sou o ViniModder



<summary>🍙 Ajuda!</summary>

## Ferramentas

```bash
> Termux
> WhatsApp
> 2 Celulares
```

---


- Get BarBarKey on [this site](https://mhankbarbar.tech)

---

## Instalar
Siga os passos abaixo!

```bash
> termux-setup-storage
(depois disso toque na permissão)
> pkg install git
> pkg install ffmpeg
> pkg install wget
> pkg install nodejs
> pkg install npm
> git clone https://github.com/BigBraim/BigBraim.git
> cd BigBraim
> bash install.sh
```

## Uso

```bash
> npm start
```

## características

| características únicas | sim
| :---------------------------------------------: | :-----------: |
|  Registrar nome e idade|✅|
|         Level    |✅|

|  FAZ  |                                           sim |
| :---------------------------------------------: | :-----------: |
| Sticker Maker|✅|
| Sticker Gif Maker|✅|
| Convert Sticker To Image|✅|
| Convert Video To MP3|✅|
| Quote Maker|✅|

| PERGUNTAS | sim |
| :-----------------: | :-------: |
| Whatis|✅|
| QuandoÉo|✅|
| VocêPode|✅|

| MEME | sim |
| :-----------------: | :-------: |
| Meme|✅|
| Meme Indo|✅|

| GRUPO | sim |
| :-----------------: | :-------: |
| Open Group|✅|
| Close Group|✅|
| Promote Member|✅|
| Demote Member|✅|
| Hide Tag|✅|
| Tag All Members|✅|
| Tag All Members2|✅|
| Tag All Members3|✅|
| Tag All Members4|✅|
| Tag All Members5|✅|
| Add Member|✅|
| Kick Member|✅|
| Show List Admins|✅|
| Leave Group|✅|
| Show Owner Group|✅|
| welcome New Members|✅|
| Nsfw|✅|
| Simih|✅|

| SOUND | sim |
| :-----------------: | :-------: |
| Text To Speach|✅|
| Play|✅|

| ISLAM | sim |
| :-----------------: | :-------: |
| Qur'an|✅|

| STALK | sim |
| :-----------------: | :-------: |
| Instagram Stalk|✅|
| Tiktok Stalk|✅|

| ANIMES | sim |
| :-----------------: | :-------: |
| Pokemon|✅|
| Nekonime|✅|

| INFORMAÇÃO | sim |
| :-----------------: | :-------: |
| List Bahasa|✅|
| List Kode Negara|✅|
| Ping|✅|

| 18+ | sim |
| :-----------------: | :-------: |
| Random Hentai|✅|
| NSFW Neko|✅|
| NSFW Trap|✅|
| NSFW Ass|✅|
| NSFW Bobs|✅|
| NSFW Sidebobs|✅|



| DONO | sim |
| :-----------------: | :-------: |
| Set Prefix|✅|
| Block Member|✅|
| Broadcast|✅|
| Group Broadcast|✅|
| Clear All Chat|✅|
| Clone Photo Profile Bot|✅|

| OUTROS | sim |
| :-----------------: | :-------: |
| WaMe|✅|
| Virtex|✅|
| Exe|✅|
| QrCode|✅|

---



## Agradecimentos especiais para

- [@adiwajshing/baileys](https://github.com/adiwajshing/Baileys) 
- [ToinNetuh](https://github.com/ToinNetuh)