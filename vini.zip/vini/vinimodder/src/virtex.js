const virtex = (prefix, pushname) => {
	return ``
}

exports.virtex = virtex
