const help = (prefix) => {
	return `
「 *bot classic* 」

◪ *informações*
  ❏ Prefix: 「  ${prefix}  」
  ❏ Criador : vini modder
  ❏ Nosso Grupo: https://chat.whatsapp.com/Ip8mlrS22AsJlehqA7zRNX

◪ *SOBRE*
  │
  ├─ ❏ ${prefix}blocklist
  ├─ ❏ ${prefix}ping
  └─ ❏ ${prefix}bugreport
◪ *FAZER*
  │
  ├─ ❏ ${prefix}sticker
  ├─ ❏ ${prefix}stickergif
  ├─ ❏ ${prefix}toimg
  ├─ ❏ ${prefix}tomp3
  └─ ❏ ${prefix}quotemaker
◪ *PERGUNTAS*
  │
  ├─ ❏ ${prefix}Whatis
  ├─ ❏ ${prefix}QuandoÉo
  ├─ ❏ ${prefix}Avaliar
  └─ ❏ ${prefix}VocêPode
◪ *MEME*
  │
  ├─ ❏ ${prefix}meme
  └─ ❏ ${prefix}memeindo
◪ *SOM*
  │
  ├─ ❏ ${prefix}play (só funciona de dia)
  └─ ❏ ${prefix}tts
◪ *ISLAM*
  │
  └─ ❏ ${prefix}quran
◪ *STALK*
  │
  ├─ ❏ ${prefix}tiktokstalk
  └─ ❏ ${prefix}igstalk
◪ *ANIMES*
  │
  ├─ ❏ ${prefix}pokemon (às vezes nn funfa)
  └─ ❏ ${prefix}nekonime
◪ *INFORMAÇÃO*
  │
  ├─ ❏ ${prefix}bahasa (idiomas)
  └─ ❏ ${prefix}kodenegara (DDI)
◪ *DONO*
  │
  ├─ ❏ ${prefix}setprefix
  ├─ ❏ ${prefix}block
  ├─ ❏ ${prefix}bc
  ├─ ❏ ${prefix}bcgc
  ├─ ❏ ${prefix}clone
  └─ ❏ ${prefix}clearall
◪ *OUTROS*
  │
  ├─ ❏ ${prefix}wame (DDD+número)
  ├─ ❏ ${prefix}exe
  └─ ❏ ${prefix}qrcode (nome)
`
}

exports.help = help
